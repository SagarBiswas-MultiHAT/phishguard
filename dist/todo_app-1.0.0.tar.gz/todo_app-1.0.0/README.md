
# To-Do List App

A production-ready, offline-first To-Do List application built with Python and Tkinter. It ships with a clean UI, structured storage backends, optional encryption, robust logging, and full developer tooling.

## Features

- Tkinter UI with search/filter, keyboard shortcuts, import/export, and undo.
- Storage backends: filesystem (text), SQLite, and optional encrypted file storage.
- Atomic saves with backup rotation and rotating logs.
- Headless CLI for exports and automated backups.
- Tested, linted, typed, and ready for packaging.

## Requirements

- Python 3.11+ (3.10 supported where feasible)
- Tkinter (bundled with standard Python installers)

## Installation

Clone the repository and install dev tools when needed:

```bash
git clone https://github.com/SagarBiswas-MultiHAT/todo-list-app.git
cd todo-list-app
```

## Quick Start

Run the UI directly:

```bash
python -m todo_app
```

Or use the CLI entry point:

```bash
todo-app ui
```

## CLI Installation

Installing the package into your active environment registers the `todo-app` console script:

```bash
pip install -e .
```

If you prefer not to install the project you can continue to run the commands via `python -m todo_app` as shown above.

### Keyboard Shortcuts

- `Ctrl+N`: add task
- `Del`: remove selected task
- `Ctrl+F`: focus search field

## CLI Usage

```bash
todo-app --storage fs ui
todo-app --storage sqlite ui
todo-app --storage encrypted --password "your password" ui
```

Headless export:

```bash
todo-app export --format json --output backups/tasks.json
todo-app export --format csv --output backups/tasks.csv
```

Automated backup (JSON):

```bash
todo-app backup --output backups/tasks-$(date +%Y%m%d).json
```

## Storage Options

The data directory defaults to an OS-appropriate location.

- Windows: `%APPDATA%\todo-app`
- macOS/Linux: `$XDG_DATA_HOME/todo-app` or `~/.local/share/todo-app`

Override with:

```bash
todo-app --data-dir /path/to/data ui
```

## Encrypted Storage

Encrypted storage uses a password-derived key (PBKDF2-HMAC-SHA256 with a per-file salt).

Install encryption extras:

```bash
pip install .[encrypt]
```

Run with:

```bash
todo-app --storage encrypted --password "your password" ui
```

If `cryptography` is missing, the app will prompt you to install it. The password is never stored.

## Import/Export

Use the File menu in the UI to import or export tasks to JSON or CSV. The CLI provides headless exports for automation.

## Logging

Rotating logs are stored in the user config directory:

- Windows: `%APPDATA%\todo-app\todo-app.log`
- macOS/Linux: `$XDG_CONFIG_HOME/todo-app/todo-app.log` or `~/.config/todo-app/todo-app.log`

## Development

Install dev dependencies:

```bash
pip install -r requirements-dev.txt
```

Run linting, type checks, and tests:

```bash
ruff check .
black --check .
mypy todo_app
pytest --maxfail=1 --disable-warnings -q --cov=todo_app
```

Run CI locally with tox:

```bash
tox
```

## Packaging

Install the build tooling before running any packaging commands:

```bash
pip install build pyinstaller
```

Build a wheel:

```bash
python -m build
```

### PyInstaller (rebuild the executable)

```bash
pyinstaller --onefile --noconsole --name todo-app todo_app/__main__.py
```

### One-click Launch

- `run_todo_app.bat` (on Windows) calls `python -m todo_app` and lives at the repo root for double-click launches.
- Use `todo-app.spec` with PyInstaller to emit `dist/todo-app.exe` for a fully packaged experience:
	```bash
	pyinstaller todo-app.spec
	```
	The bundled executable appears in the `dist/` directory and can be copied alongside the shared config/storage directory. (.\dist\todo-app.exe)

## Troubleshooting

- **UI does not open**: ensure Tkinter is installed with your Python distribution.
- **Encrypted storage error**: install `cryptography` and confirm the password.
- **Permission errors**: choose a custom `--data-dir` with write access.

## Security

See [SECURITY.md](SECURITY.md) for the threat model and secure defaults.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).
